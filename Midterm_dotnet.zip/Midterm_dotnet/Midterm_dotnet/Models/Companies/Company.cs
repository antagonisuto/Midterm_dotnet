﻿using System;
using System.ComponentModel.DataAnnotations;

public class Company
{
    /// <summary>
    /// Company ID
    /// </summary>
    [Display(Name = "Id")]
    public int Id { get; set; }

    /// <summary>
    /// Name
    /// </summary>
    [Display(Name = "CompanyName")]
    public string Name { get; set; }

    /// <summary>
    /// Description
    /// </summary>
    [Display(Name = "Desc")]
    public string Desc { get; set; }


    /// <summary>
    /// List Employee
    /// </summary>
    [Display(Name = "List of employees (by comma)")]
    public string Empl { get; set; }

    /// <summary>
    /// Salaries Summary
    /// </summary>
    [Display(Name = "SalSum")]
    public int SalSum { get; set; }

    /// <summary>
    /// Movie id
    /// </summary>
    [Display(Name = "TotBud")]
    public int TotBud { get; set; }

    internal void Add(Company company)
    {
        throw new NotImplementedException();
    }
}
