﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

public class HomeController : Controller
{

    static List<Company> companies = new List<Company>
    {
            new Company { Name = "Todd Phillips", Empl = "Crime , Drama , Thriller", Desc = "Joker", SalSum = 324, TotBud=2436},
            new Company { Name = "Todd Phillips", Empl = "Crime , Drama , Thriller", Desc = "Joker", SalSum = 324, TotBud=2436},
            new Company { Name = "Todd Phillips", Empl = "Crime , Drama , Thriller", Desc = "Joker", SalSum = 324, TotBud=2436},
            new Company { Name = "Todd Phillips", Empl = "Crime , Drama , Thriller", Desc = "Joker", SalSum = 324, TotBud=2436},
            new Company { Name = "Todd Phillips", Empl = "Crime , Drama , Thriller", Desc = "Joker", SalSum = 324, TotBud=2436}
    };


    public IActionResult Index()
    {

        return View(companies);
    }

    [HttpGet]
    public IActionResult Add()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Add(Company company)
    {
        companies.Add(company);

        return View("Index", companies);
    }
}