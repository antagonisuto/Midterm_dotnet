﻿using System;
using Microsoft.EntityFrameworkCore;

    public class CompanyContext : DbContext
    {
        public CompanyContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Company> Company { get; set; }
    }
